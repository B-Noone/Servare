﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoreHealth : MonoBehaviour {
    public float coreHealth = 100;
}
